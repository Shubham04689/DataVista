import React, { useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import './styles.css';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const App: React.FC = () => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState('');
  const [vizSuggestion, setVizSuggestion] = useState('');
  const [chartData, setChartData] = useState<any>(null);

  const handleQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/qa', { question });
      setAnswer(response.data.answer);
    } catch (error) {
      console.error('Error submitting question:', error);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const formData = new FormData();
      formData.append('file', selectedFile);

      try {
        const response = await axios.post('http://localhost:8000/upload-csv', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        setAnalysis(response.data.analysis);
        setVizSuggestion(response.data.visualization_suggestion);
        setChartData(response.data.chart_data);
      } catch (error) {
        console.error('Error uploading file:', error);
      }
    }
  };

  return (
    <div className="app-container">
      <header>
        <h1>Business Insights AI</h1>
      </header>
      <main>
        <section className="qa-section">
          <h2>Ask a Question</h2>
          <form onSubmit={handleQuestionSubmit}>
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question here"
            />
            <button type="submit">Submit</button>
          </form>
          {answer && (
            <div className="answer">
              <h3>Answer:</h3>
              <p>{answer}</p>
            </div>
          )}
        </section>

        <section className="file-upload-section">
          <h2>Upload CSV File</h2>
          <input type="file" accept=".csv" onChange={handleFileUpload} />
          {file && <p>Selected file: {file.name}</p>}
        </section>

        {analysis && (
          <section className="analysis-section">
            <h2>Analysis Results</h2>
            <p>{analysis}</p>
            <h3>Visualization Suggestion:</h3>
            <p>{vizSuggestion}</p>
          </section>
        )}

        {chartData && (
          <section className="chart-section">
            <h2>Data Visualization</h2>
            <Bar
              data={{
                labels: chartData.x,
                datasets: [
                  {
                    label: 'Data',
                    data: chartData.y,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                  },
                ],
              }}
              options={{
                responsive: true,
                plugins: {
                  legend: {
                    position: 'top' as const,
                  },
                  title: {
                    display: true,
                    text: 'Data Visualization',
                  },
                },
              }}
            />
          </section>
        )}
      </main>
    </div>
  );
};

export default App;
