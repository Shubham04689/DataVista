import React, { useState } from 'react';
import { Box, Button, Input, VStack } from '@chakra-ui/react';

interface FileUploadProps {
  setChartData: (data: any) => void;
  setAnalysis: (analysis: string) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ setChartData, setAnalysis }) => {
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('http://localhost:8000/upload-csv', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      setChartData(data.chart_data);
      setAnalysis(data.analysis);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <Box>
      <VStack spacing={4}>
        <Input type="file" onChange={handleFileChange} accept=".csv" />
        <Button onClick={handleUpload} disabled={!file}>
          Upload CSV
        </Button>
      </VStack>
    </Box>
  );
};

export default FileUpload;
