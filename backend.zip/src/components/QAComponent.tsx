import React, { useState } from 'react';
import { Box, Input, Button, Text, VStack } from '@chakra-ui/react';

const QAComponent = () => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8000/qa', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question }),
      });
      const data = await response.json();
      setAnswer(data.answer);
    } catch (error) {
      console.error('Error:', error);
      setAnswer('An error occurred while fetching the answer.');
    }
  };

  return (
    <Box>
      <form onSubmit={handleSubmit}>
        <VStack spacing={4}>
          <Input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question"
          />
          <Button type="submit">Submit</Button>
        </VStack>
      </form>
      {answer && (
        <Box mt={4}>
          <Text fontWeight="bold">Answer:</Text>
          <Text>{answer}</Text>
        </Box>
      )}
    </Box>
  );
};

export default QAComponent;
