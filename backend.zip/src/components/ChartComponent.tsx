import React from 'react';
import { Box } from '@chakra-ui/react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface ChartComponentProps {
  data: {
    x: string[];
    y: number[];
    type: string;
  };
}

const ChartComponent: React.FC<ChartComponentProps> = ({ data }) => {
  const chartData = {
    labels: data.x,
    datasets: [
      {
        label: 'Data',
        data: data.y,
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Chart',
      },
    },
  };

  return (
    <Box width="100%" maxWidth="600px">
      <Bar data={chartData} options={options} />
    </Box>
  );
};

export default ChartComponent;
