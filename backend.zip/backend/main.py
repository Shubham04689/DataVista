from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.responses import JSONResponse
import ollama
import os

from database import init_db, save_qa, save_analysis
from ai_utils import init_rag, analyze_csv

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database and RAG system
init_db()
qa_system = init_rag("business_data.txt", "llama3.2:3b")

class Question(BaseModel):
    question: str

@app.post("/qa")
async def answer_question(question: Question):
    """Answer the question using the RAG system."""
    if qa_system is None:
        return JSONResponse(content={"error": "RAG system not initialized"}, status_code=503)
    
    response = qa_system.run(question.question)
    save_qa(question.question, response)
    return JSONResponse(content={"answer": response})

@app.post("/qa-stream")
async def answer_question_stream(question: Question):
    """Answer the question with a streaming response using Ollama."""
    stream = ollama.chat(
        model='llama3.2:3b', 
        messages=[{'role': 'user', 'content': question.question}],
        stream=True
    )
    
    answer = ""
    for chunk in stream:
        answer += chunk['message']['content']
    
    save_qa(question.question, answer)
    return JSONResponse(content={"answer": answer})

@app.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...)):
    """Upload and process CSV data, generate insights, and visualize it."""
    file_path = f"temp_{file.filename}"
    try:
        with open(file_path, "wb") as temp_file:
            temp_file.write(file.file.read())
        
        analysis_result, viz_suggestion, chart_data = analyze_csv(file_path, "llama3.2:3b")
        save_analysis("CSV Analysis", analysis_result, file.filename)

        return JSONResponse(content={
            "analysis": analysis_result,
            "visualization_suggestion": viz_suggestion,
            "chart_data": chart_data
        })
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
