import sqlite3
import os

DB_NAME = 'business_data.db'

def init_db():
    """Initialize the database."""
    if not os.path.exists(DB_NAME):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''CREATE TABLE user_data
                     (id INTEGER PRIMARY KEY, question TEXT, answer TEXT, filename TEXT)''')
        conn.commit()
        conn.close()

def save_qa(question: str, answer: str):
    """Save question and answer to the database."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO user_data (question, answer) VALUES (?, ?)", (question, answer))
    conn.commit()
    conn.close()

def save_analysis(question: str, answer: str, filename: str):
    """Save analysis to the database."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO user_data (question, answer, filename) VALUES (?, ?, ?)", 
              (question, answer, filename))
    conn.commit()
    conn.close()
