from langchain_community.llms import Ollama
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
import pandas as pd
import os

def init_rag(file_path: str, model_name: str):
    """Initialize the Retrieval-Augmented Generation system."""
    if not os.path.exists(file_path):
        print(f"Warning: {file_path} not found. Skipping RAG initialization.")
        return None

    loader = TextLoader(file_path)
    documents = loader.load()
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
    texts = text_splitter.split_documents(documents)

    llm = Ollama(model=model_name)
    embeddings = OllamaEmbeddings(model="nomic-embed-text")
    docsearch = FAISS.from_documents(texts, embeddings)

    return RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=docsearch.as_retriever())

def analyze_csv(file_path: str, model_name: str):
    """Analyze CSV data using Ollama."""
    df = pd.read_csv(file_path)
    llm = Ollama(model=model_name)

    analysis_prompt = f"Analyze this dataset and provide key insights, trends, and any notable patterns. Also suggest potential visualizations that would be useful. Here's a summary of the data:\n\n{df.describe().to_string()}\n\nFirst few rows:\n{df.head().to_string()}"
    analysis_result = llm.predict(analysis_prompt)

    viz_prompt = f"Suggest a simple visualization for this data, specifying the chart type and which columns to use. Here's a summary of the data:\n\n{df.describe().to_string()}\n\nColumn names: {', '.join(df.columns)}"
    viz_suggestion = llm.predict(viz_prompt)

    return analysis_result, viz_suggestion, generate_chart_data(df, viz_suggestion)

def generate_chart_data(df, viz_suggestion):
    """Generate chart data based on Ollama suggestion."""
    if 'bar' in viz_suggestion.lower() and len(df.columns) >= 2:
        return {
            "x": df.iloc[:, 0].tolist(),
            "y": df.iloc[:, 1].tolist(),
            "type": "bar"
        }
    elif 'line' in viz_suggestion.lower() and len(df.columns) >= 2:
        return {
            "x": df.iloc[:, 0].tolist(),
            "y": df.iloc[:, 1].tolist(),
            "type": "line"
        }
    else:
        return {"error": "Could not generate appropriate chart data based on the suggestion."}
